import { useCallback, useEffect, useRef, useState } from "react";
import Globe from "react-globe.gl";
import "./App.css";

const continents = {
  Australia: {
    emoji: "🦘",
    subtitle: "The world's smallest continent",
    coordinates: { lat: -25, lng: 133, altitude: 0.75 },
    facts: [
      ["Area", "About 7.7 million km²"],
      ["Population", "About 27 million people"],
      ["Highest point", "Mount Kosciuszko, 2,228 m"],
      ["Largest city", "Sydney"],
      ["Climate", "Tropical, desert, temperate and alpine"],
      ["Surrounding oceans", "Indian and Pacific"],
    ],
    sections: [
      {
        title: "Geography",
        text: "Australia contains vast deserts, tropical rainforests, mountain ranges, fertile coastal regions and the Great Barrier Reef. Most people live near the coast.",
      },
      {
        title: "Wildlife",
        text: "Kangaroos, koalas, wombats, platypuses and emus are among its best-known native animals. Many Australian species are found nowhere else.",
      },
      {
        title: "Climate",
        text: "The north is generally tropical, the interior is largely arid, and the south has more temperate conditions. Seasons are opposite to those in the Northern Hemisphere.",
      },
      {
        title: "People and culture",
        text: "Aboriginal and Torres Strait Islander peoples have diverse cultures and histories stretching back tens of thousands of years. Modern Australia is also home to communities from around the world.",
      },
      {
        title: "Places to explore",
        text: "Explore the Great Barrier Reef, Uluru, the Australian Alps, the Daintree Rainforest, Sydney Harbour and the vast Outback.",
      },
    ],
  },
  Antarctica: {
    emoji: "❄️",
    subtitle: "The coldest continent on Earth",
    coordinates: { lat: -82, lng: 20, altitude: 0.8 },
    facts: [
      ["Area", "About 14 million km²"],
      ["Population", "No permanent native population"],
      ["Highest point", "Vinson Massif, 4,892 m"],
      ["Largest settlement", "McMurdo Station (research base)"],
      ["Climate", "Polar desert"],
      ["Location", "Around the South Pole"],
    ],
    sections: [
      {
        title: "Geography",
        text: "Antarctica is surrounded by the Southern Ocean and covered by a vast ice sheet. Beneath the ice are mountains, valleys and subglacial lakes.",
      },
      {
        title: "Wildlife",
        text: "Penguins, seals, whales and seabirds live in or around Antarctica. Most animals depend on the ocean for food; polar bears do not live here.",
      },
      {
        title: "Climate",
        text: "It is the coldest continent and a polar desert. The interior is extremely dry, and temperatures vary greatly between the coast and the high ice sheet.",
      },
      {
        title: "Research and discovery",
        text: "Scientists study ice cores, climate history, astronomy, geology and ecosystems. Research stations operate seasonally or year-round, with populations changing by season.",
      },
      {
        title: "Protection",
        text: "The Antarctic Treaty system supports peaceful scientific cooperation and environmental protection. Antarctica has no ordinary sovereign country or permanent civilian population.",
      },
    ],
  },
};

const locations = Object.entries(continents).map(([name, data]) => ({
  name,
  lat: data.coordinates.lat,
  lng: data.coordinates.lng,
  color: name === "Australia" ? "#65f5bd" : "#85d9ff",
}));

function identifyContinent(lat, lng) {
  if (lat <= -60) return "Antarctica";
  if (lat >= -45 && lat <= -10 && lng >= 112 && lng <= 155) {
    return "Australia";
  }
  return null;
}

export default function App() {
  const globeRef = useRef();
  const containerRef = useRef();
  const [size, setSize] = useState({ width: 800, height: 600 });
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    const observer = new ResizeObserver(([entry]) => {
      setSize({
        width: entry.contentRect.width,
        height: entry.contentRect.height,
      });
    });

    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  const explore = useCallback((name) => {
    const continent = continents[name];
    if (!continent) return;
    setSelected(name);
    globeRef.current?.pointOfView(continent.coordinates, 1500);
  }, []);

  const handleGlobeClick = useCallback(({ lat, lng }) => {
    const name = identifyContinent(lat, lng);
    if (name) explore(name);
  }, [explore]);

  const resetGlobe = () => {
    setSelected(null);
    globeRef.current?.pointOfView({ lat: 15, lng: 10, altitude: 2.5 }, 1200);
  };

  const continent = selected ? continents[selected] : null;

  return (
    <main className="app">
      <header className="topbar">
        <a className="brand" href="#" onClick={(event) => { event.preventDefault(); resetGlobe(); }}>
          <span className="brand-icon">◎</span>
          EARTH<span className="brand-light">SCAPE</span>
        </a>
        <span className="live-label">
          <span className="live-dot" /> INTERACTIVE WORLD ATLAS
        </span>
      </header>

      <section className={`explorer ${selected ? "has-selection" : ""}`}>
        <div className="globe-area" ref={containerRef}>
          <div className="globe-heading">
            <p className="eyebrow">YOUR PLANET, YOUR JOURNEY</p>
            <h1>Explore beyond<br /><span>the horizon.</span></h1>
            <p className="instruction">Drag to rotate · Scroll to zoom · Select a continent</p>
          </div>

          <Globe
            ref={globeRef}
            width={size.width}
            height={size.height}
            globeImageUrl="https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg"
            bumpImageUrl="https://unpkg.com/three-globe/example/img/earth-topology.png"
            backgroundImageUrl="https://unpkg.com/three-globe/example/img/night-sky.png"
            showAtmosphere
            atmosphereColor="#65b9ff"
            atmosphereAltitude={0.16}
            pointsData={locations}
            pointLat="lat"
            pointLng="lng"
            pointColor="color"
            pointAltitude={0.025}
            pointRadius={0.55}
            pointLabel="name"
            onPointClick={(point) => explore(point.name)}
            onGlobeClick={handleGlobeClick}
            animateIn
            enablePointerInteraction
          />

          <div className="globe-hint"><span className="hint-icon">✦</span>Choose a destination</div>
        </div>

        <aside className="side-panel">
          {!continent ? (
            <div className="welcome-panel">
              <p className="eyebrow">START EXPLORING</p>
              <h2>Where will you go?</h2>
              <p className="panel-description">
                Select a destination to zoom into the globe and discover its geography,
                wildlife, climate, people and remarkable places.
              </p>
              <div className="destination-list">
                {Object.entries(continents).map(([name, data]) => (
                  <button key={name} className="destination" onClick={() => explore(name)}>
                    <span className="destination-emoji">{data.emoji}</span>
                    <span className="destination-copy">
                      <strong>{name}</strong><small>{data.subtitle}</small>
                    </span>
                    <span className="destination-arrow">↗</span>
                  </button>
                ))}
              </div>
              <div className="tip-card">
                <span>✧</span>
                <p><strong>Explorer tip</strong><br />You can also click directly on the globe near either continent.</p>
              </div>
            </div>
          ) : (
            <div className="detail-panel">
              <button className="back-button" onClick={resetGlobe}>← Back to the globe</button>
              <p className="eyebrow">DESTINATION / 0{selected === "Australia" ? "1" : "2"}</p>
              <div className="continent-title"><span>{continent.emoji}</span><h2>{selected}</h2></div>
              <p className="panel-description">{continent.subtitle}</p>
              <h3 className="section-label">AT A GLANCE</h3>
              <div className="facts-grid">
                {continent.facts.map(([label, value]) => (
                  <div className="fact" key={label}><span>{label}</span><strong>{value}</strong></div>
                ))}
              </div>
              <h3 className="section-label">DISCOVER THIS CONTINENT</h3>
              <div className="discovery-list">
                {continent.sections.map((section, index) => (
                  <details className="discovery" key={section.title} open={index === 0}>
                    <summary><span>{section.title}</span><span className="plus">+</span></summary>
                    <p>{section.text}</p>
                  </details>
                ))}
              </div>
              <p className="data-note">Figures are approximate and intended as an introduction.</p>
            </div>
          )}
        </aside>
      </section>

      <footer className="footer">
        <span>EARTHSCAPE © 2026</span><span>ONE PLANET · ENDLESS DISCOVERIES</span>
      </footer>
    </main>
  );
}
