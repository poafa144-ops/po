import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // GitHub Actions builds the site for the repository URL.
  // If your repository is named something other than "earth-explorer",
  // change this to "/YOUR-REPOSITORY-NAME/".
  base: "/earth-explorer/",
});
