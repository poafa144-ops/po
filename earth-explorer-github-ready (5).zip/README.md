# Earthscape — Interactive Earth Explorer

A React + Vite website featuring an interactive 3D globe and exploration panels for Australia and Antarctica.

## Run locally

Requirements: Node.js (LTS recommended).

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Publish to GitHub Pages (recommended: GitHub Actions)

1. Create a GitHub repository named **earth-explorer**.
2. Upload/push all files in this folder to the repository's `main` branch.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **GitHub Actions**.
5. Open the **Actions** tab and wait for the workflow named **Deploy to GitHub Pages** to finish.
6. Your site will be available at `https://YOUR-GITHUB-USERNAME.github.io/earth-explorer/`.

If you use a different repository name, edit `base` in `vite.config.js` to `"/YOUR-REPOSITORY-NAME/"` before publishing.

## Notes

- The globe imagery is loaded from public URLs, so an internet connection is needed.
- The starter uses approximate click regions for Australia and Antarctica; a future upgrade can add true geographic boundary polygons and detailed terrain.
- Population and area figures are approximate introductory values.
